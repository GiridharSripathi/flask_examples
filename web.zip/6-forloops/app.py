from flask import Flask,render_template


app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    sysuser = "Mr.Ram"
    empdata = [['emp1',1001],['emp2',1002],['emp3',1003],['emp1',1004],['emp1',1005]]
    return render_template('index.html', title='Home' , info = empdata , sysuser = sysuser )


app.run(debug = True)