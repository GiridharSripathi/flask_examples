from flask import Flask
import os
from flask import render_template, flash, redirect


app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '11117d441f27d441f27567d441f2b6176a'
 

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')
    
    
    


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        flash('Login requested for user {}, remember_me={}'.format(form.username.data, form.remember_me.data))
        return redirect('/login')
    return render_template('login.html', title='Sign In', form=form)




app.run(debug = True)