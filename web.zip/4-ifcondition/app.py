from flask import Flask,render_template


app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    username = 'Ram'
    langdict = {'language':'python'}
    return render_template('index.html', title='Home', languagesdict = langdict, sysuser = username)


app.run(debug = True)