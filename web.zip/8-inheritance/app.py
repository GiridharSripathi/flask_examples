from flask import Flask,render_template

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'giri'}
    posts = [
        {
            'author': {'username': 'python'},
            'body': 'python is general purpose language'
        },
        {
            'author': {'username': 'ruby'},
            'body': 'Ruby is the scripting language'
        }
    ]
    return render_template('index.html', title='Home', user=user, posts=posts)



app.run(debug = True)